from setuptools import setup

setup(name='all_stats_distributions',
      version='0.1',
      description='Gaussian distributions',
      packages=['all_stats_distributions'],
      author='Shashank Raj',
      author_email='shashank.raj2009@gmail.com',
      zip_safe=False)
